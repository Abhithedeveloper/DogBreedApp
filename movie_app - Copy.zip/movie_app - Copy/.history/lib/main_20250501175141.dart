import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:movie_app/features/dogbreed/data/datasources/dog_breed_remote_datasource.dart';
import 'package:movie_app/features/dogbreed/data/repositories/breed_repository_impl.dart';
import 'package:movie_app/features/dogbreed/presentation/bloc/dogbreed_bloc.dart';
import 'package:movie_app/features/dogbreed/presentation/pages/breed_list_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: BlocProvider(
        create:
            (context) => BreedBloc(
              breedRepository: BreedRepositoryImpl(
                remoteDataSource: BreedRemoteDataSource(client: http.Client()),
              ),
            ),
        child: const BreedListScreen(),
      ),
    );
  }
}
