import 'package:flutter/material.dart';
import 'package:movie_app/features/dogbreed/presentation/pages/breed_list_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigate();
  }

  Future<void> _navigate() async {
    Navigator.pushReplacement(
      // ignore: use_build_context_synchronously
      context,
      MaterialPageRoute(builder: (_) => const BreedListScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
