import 'package:connectivity_plus/connectivity_plus.dart';

abstract class NetworkInfo {
  Future<bool> get isConnected;
}

// core/network/network_checker.dart

class NetworkChecker implements NetworkInfo {
  final Connectivity connectivity;

  NetworkChecker(this.connectivity);

  @override
  Future<bool> get isConnected async {
    final result = await connectivity.checkConnectivity();
    return result != ConnectivityResult.none;
  }
}
