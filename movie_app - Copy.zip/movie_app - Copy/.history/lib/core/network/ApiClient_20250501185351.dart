class ApiConstants {
  static const String baseUrl = "https://dogapi.dog/";

  static const String getbreed = "${baseUrl}api/v2/breeds";
 
}