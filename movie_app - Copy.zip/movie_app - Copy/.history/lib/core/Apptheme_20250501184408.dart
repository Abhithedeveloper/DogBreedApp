
import 'package:flutter/material.dart';
import 'package:movie_app/core/constant/custom_color.dart';



class AppTheme {
  static ThemeData lightTheme = ThemeData(
    primaryColor: CustomColors.themecolor,
    scaffoldBackgroundColor: Colors.white,
    appBarTheme: AppBarTheme(
      backgroundColor: CustomColors.themecolor,
      foregroundColor: Colors.white, 
      elevation: 0,
    ),
    colorScheme: ColorScheme.fromSeed(
      seedColor: CustomColors.themecolor,
    ),
  );
}