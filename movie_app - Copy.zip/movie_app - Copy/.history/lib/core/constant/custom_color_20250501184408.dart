import 'dart:ui';

import 'package:flutter/material.dart';

class CustomColors{
  static Color  themecolor=const Color(0xffCF7AC2);
  static  Color violet=const Color(0xff260620); 
  static  Color grey=const Color(0xffC1C1C1); 
  static const Color white=Colors.white;
  static const Color black=Colors.black; 
  static const Color transparent=Colors.transparent;
  static Color? grey600=Colors.grey[600];
  static Color? grey300=Colors.grey[300];
  static Color? grey200=Colors.grey[200];
  static Color? blue100=Colors.blue[100];
  static const Color shadowcolor=Color.fromARGB(255, 207, 205, 205);  
    static const Color backgroundColor = Color(0xFFF5F5F5); 
  
}