import 'package:flutter/material.dart';
import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';

class BreedCard extends StatelessWidget {
  final BreedModel breed;

  const BreedCard({Key? key, required this.breed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              breed.name,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              breed.description,
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('Life Expectancy: '),
                Text('${breed.lifeMin} - ${breed.lifeMax} years'),
              ],
            ),
            Row(
              children: [
                const Text('Male Weight: '),
                Text('${breed.maleWeightMin} - ${breed.maleWeightMax} kg'),
              ],
            ),
            Row(
              children: [
                const Text('Female Weight: '),
                Text('${breed.femaleWeightMin} - ${breed.femaleWeightMax} kg'),
              ],
            ),
            Row(
              children: [
                const Text('Hypoallergenic: '),
                Text(breed.hypoallergenic ? 'Yes' : 'No'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}