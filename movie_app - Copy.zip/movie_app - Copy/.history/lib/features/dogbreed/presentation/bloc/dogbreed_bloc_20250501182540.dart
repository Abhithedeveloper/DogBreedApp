import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';
import 'package:movie_app/features/dogbreed/domain/repositories/breed_reporitory.dart';
import 'package:movie_app/features/dogbreed/domain/usecases/breed_usecase.dart';

part 'dogbreed_event.dart';
part 'dogbreed_state.dart';
class BreedBloc extends Bloc<DogbreedEvent, DogbreedState> {
  final GetBreeds getDogs;

  BreedBloc(this.getDogs) : super(BreedInitial()) {
    on<FetchBreedsEvent>((event, emit) async {
      emit(BreedLoading());
      try {
        final dogs = await getDogs();
        emit(BreedLoaded(breeds: dogs));
      } catch (e) {
       emit(BreedError(message: e.toString()));
      }
    });
  }
}


// class BreedBloc extends Bloc<DogbreedEvent, DogbreedState> {
//   final BreedRepository breedRepository;

//   BreedBloc({required this.breedRepository}) : super(BreedInitial()) {
//     on<FetchBreedsEvent>((event, emit) async {
//       emit(BreedLoading());
//       try {
//         final breeds = await breedRepository.getBreeds();
//         emit(BreedLoaded(breeds: breeds));
//       } catch (e) {
//         emit(BreedError(message: e.toString()));
//       }
//     });
//   }
// }
