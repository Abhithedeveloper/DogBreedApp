part of 'dogbreed_bloc.dart';

abstract class DogbreedState extends Equatable {
  const DogbreedState();  

  @override
  List<Object> get props => [];
}
class DogbreedInitial extends DogbreedState {}
