part of 'dogbreed_bloc.dart';

abstract class DogbreedState extends Equatable {
  const DogbreedState();

  @override
  List<Object> get props => [];
}

class BreedInitial extends DogbreedState {}

class BreedLoading extends DogbreedState {}

class BreedLoaded extends DogbreedState {
  final List<BreedModel> breeds;

  const BreedLoaded({required this.breeds});
}

class BreedError extends DogbreedState {
  final String message;

  const BreedError({required this.message});
}
