import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'dogbreed_event.dart';
part 'dogbreed_state.dart';

class DogbreedBloc extends Bloc<DogbreedEvent, DogbreedState> {
  DogbreedBloc() : super(DogbreedInitial()) {
    on<DogbreedEvent>((event, emit) {
      // TODO: implement event handler
    });
  }
}
