part of 'dogbreed_bloc.dart';

abstract class DogbreedEvent extends Equatable {
  const DogbreedEvent();

  @override
  List<Object> get props => [];
}
class FetchBreedsEvent extends DogbreedEvent {}