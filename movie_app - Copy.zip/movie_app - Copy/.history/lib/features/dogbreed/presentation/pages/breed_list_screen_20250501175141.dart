import 'package:flutter/material.dart';
import 'package:movie_app/features/dogbreed/presentation/bloc/dogbreed_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:movie_app/features/dogbreed/presentation/widgets/breed_card.dart';

class BreedListScreen extends StatefulWidget {
  const BreedListScreen({super.key});

  @override
  State<BreedListScreen> createState() => _BreedListScreenState();
}

class _BreedListScreenState extends State<BreedListScreen> {
  @override
  void initState() {
    super.initState();
    BlocProvider.of<BreedBloc>(context).add(FetchBreedsEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dog Breeds'),
      ),
      body: BlocBuilder<BreedBloc, DogbreedState>(
        builder: (context, state) {
          if (state is BreedLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is BreedLoaded) {
            return ListView.builder(
              itemCount: state.breeds.length,
              itemBuilder: (context, index) {
                final breed = state.breeds[index];
                return BreedCard(breed: breed);
              },
            );
          } else if (state is BreedError) {
            return Center(child: Text('Error: ${state.message}'));
          } else {
            return const Center(child: Text('No data'));
          }
        },
      ),
    );
  }
}