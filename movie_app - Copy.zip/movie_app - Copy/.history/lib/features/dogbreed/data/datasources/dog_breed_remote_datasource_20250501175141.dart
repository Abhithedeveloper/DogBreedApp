import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';

class BreedRemoteDataSource {
  final http.Client client;

  BreedRemoteDataSource({required this.client});

  Future<List<BreedModel>> getBreeds() async {
    final response = await client.get(
      Uri.parse('https://dogapi.dog/api/v2/breeds'),
      headers: {'accept': 'application/json'},
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> jsonResponse = jsonDecode(response.body);
      final List<dynamic> data = jsonResponse['data'];
      return data.map((item) => BreedModel.fromJson(item)).toList();
    } else {
      throw Exception('Failed to load breeds. Status code: ${response.statusCode}');
    }
  }
}