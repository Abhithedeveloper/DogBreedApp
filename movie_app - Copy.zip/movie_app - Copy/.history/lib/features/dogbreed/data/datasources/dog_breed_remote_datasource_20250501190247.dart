import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:movie_app/core/network/ApiClient.dart';
import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';

class BreedRemoteDataSource {
  final http.Client client;

  BreedRemoteDataSource({required this.client});

  Future<List<BreedModel>> getBreeds() async {
    final response = await client.get(
      Uri.parse(ApiConstants.getbreed),
      headers: {'accept': 'application/json'},
    );
    switch (response.statusCode) {
      case 200:
        final Map<String, dynamic> jsonResponse = jsonDecode(response.body);
        final List<dynamic> data = jsonResponse['data'];
        return data.map((item) => BreedModel.fromJson(item)).toList();

      case 400:
        throw Exception('Bad request. Please check the request parameters.');

      case 401:
        throw Exception(
          'Unauthorized. Please check your authentication credentials.',
        );

      case 404:
        throw Exception(
          'Not found. The requested resource could not be found.',
        );

      case 500:
        throw Exception('Internal server error. Please try again later.');

      default:
        throw Exception(
          'Failed to load breeds. Status code: ${response.statusCode}',
        );
    }

   
  }
}
