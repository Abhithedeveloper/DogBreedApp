import 'package:movie_app/features/dogbreed/data/datasources/dog_breed_remote_datasource.dart';
import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';
import 'package:movie_app/features/dogbreed/domain/repositories/breed_reporitory.dart';

class BreedRepositoryImpl implements BreedRepository {
  final BreedRemoteDataSource remoteDataSource;

  BreedRepositoryImpl({required this.remoteDataSource});

  @override
  Future<List<BreedModel>> getBreeds() async {
    try {
      return await remoteDataSource.getBreeds();
    } catch (e) {
      throw Exception('Failed to fetch breeds from remote source: $e');
    }
  }
}

