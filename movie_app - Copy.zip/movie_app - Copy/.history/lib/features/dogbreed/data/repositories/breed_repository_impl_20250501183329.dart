import 'package:movie_app/core/network/network_info.dart';
import 'package:movie_app/features/dogbreed/data/datasources/dog_breed_remote_datasource.dart';
import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';
import 'package:movie_app/features/dogbreed/domain/repositories/breed_reporitory.dart';

class BreedRepositoryImpl implements BreedRepository {
  final BreedRemoteDataSource remoteDataSource;
   final NetworkInfo networkInfo;

  BreedRepositoryImpl({required this.remoteDataSource, required this.networkInfo});

  @override
  Future<List<BreedModel>> getBreeds() async {
    try {
      if(await networkInfo.isConnected){
         return await remoteDataSource.getBreeds();
      }else{
        throw Exception('No Internet Connection');
      }
     
    } catch (e) {
      throw Exception('Failed to fetch breeds from remote source: $e');
    }
  }
}

