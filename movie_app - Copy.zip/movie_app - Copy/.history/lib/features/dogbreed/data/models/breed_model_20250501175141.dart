class BreedModel {
  final String id;
  final String name;
  final String description;
  final int lifeMin;
  final int lifeMax;
  final int maleWeightMin;
  final int maleWeightMax;
  final int femaleWeightMin;
  final int femaleWeightMax;
  final bool hypoallergenic;
  final String? groupId;

  BreedModel({
    required this.id,
    required this.name,
    required this.description,
    required this.lifeMin,
    required this.lifeMax,
    required this.maleWeightMin,
    required this.maleWeightMax,
    required this.femaleWeightMin,
    required this.femaleWeightMax,
    required this.hypoallergenic,
    this.groupId,
  });

  factory BreedModel.fromJson(Map<String, dynamic> json) {
    return BreedModel(
      id: json['id'],
      name: json['attributes']['name'] ?? 'N/A',
      description: json['attributes']['description'] ?? 'N/A',
      lifeMin: json['attributes']['life']?['min'] ?? 0,
      lifeMax: json['attributes']['life']?['max'] ?? 0,
      maleWeightMin: json['attributes']['male_weight']?['min'] ?? 0,
      maleWeightMax: json['attributes']['male_weight']?['max'] ?? 0,
      femaleWeightMin: json['attributes']['female_weight']?['min'] ?? 0,
      femaleWeightMax: json['attributes']['female_weight']?['max'] ?? 0,
      hypoallergenic: json['attributes']['hypoallergenic'] ?? false,
      groupId: json['relationships']['group']['data']?['id'],
    );
  }
}
