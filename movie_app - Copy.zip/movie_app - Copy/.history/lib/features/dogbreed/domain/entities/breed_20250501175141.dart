class Breed {
  final String id;
  final String name;
  final String description;
  final int lifeMin;
  final int lifeMax;
  final double maleWeightMin;
  final double maleWeightMax;
  final double femaleWeightMin;
  final double femaleWeightMax;
  final bool hypoallergenic;

  Breed({
    required this.id,
    required this.name,
    required this.description,
    required this.lifeMin,
    required this.lifeMax,
    required this.maleWeightMin,
    required this.maleWeightMax,
    required this.femaleWeightMin,
    required this.femaleWeightMax,
    required this.hypoallergenic,
  });
}
