import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';

abstract class BreedRepository {
  Future<List<BreedModel>> getBreeds();
}
