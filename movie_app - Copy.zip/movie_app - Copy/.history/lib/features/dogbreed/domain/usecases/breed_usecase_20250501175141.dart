import 'package:movie_app/features/dogbreed/data/models/breed_model.dart';

import 'package:movie_app/features/dogbreed/domain/repositories/breed_reporitory.dart';

class GetBreeds {
  final BreedRepository repository;

  GetBreeds(this.repository);

  Future<List<BreedModel>> call() async {
    return await repository.getBreeds();
  }
}
