import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:movie_app/core/network/network_info.dart';
import 'package:movie_app/features/dogbreed/data/datasources/dog_breed_remote_datasource.dart';
import 'package:movie_app/features/dogbreed/data/repositories/breed_repository_impl.dart';
import 'package:movie_app/features/dogbreed/domain/usecases/breed_usecase.dart';
import 'package:movie_app/features/dogbreed/presentation/bloc/dogbreed_bloc.dart';
import 'package:movie_app/features/dogbreed/presentation/pages/breed_list_screen.dart';
import 'package:movie_app/splash_screen.dart';

void main() {
  final client = http.Client();
  final connectivity = Connectivity();
  final networkChecker = NetworkChecker(connectivity);
  final dataSource = BreedRemoteDataSource(client: client);
  final repository = BreedRepositoryImpl(remoteDataSource: dataSource, networkInfo: networkChecker);
  final getDogs = GetBreeds(repository);
  

  runApp(MyApp(getDogs: getDogs));
}

class MyApp extends StatelessWidget {
  final GetBreeds? getDogs;
  const MyApp({super.key,  this.getDogs});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home:  BlocProvider(
        create: (_) => BreedBloc(getDogs!),
        child: SplashScreen(),
      ),
    );
  }
}
